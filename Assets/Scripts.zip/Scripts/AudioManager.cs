
using UnityEngine;

public class AudioManager : MonoBehaviour
{
    public static AudioManager Instance { get; private set; }

    [Header("Audio Source")]
    public AudioSource sfxSource;

    [Header("Combat Sounds")]
    public AudioClip rockSound;
    public AudioClip paperSound;
    public AudioClip scissorsSound;
    public AudioClip blockSound;
    public AudioClip counterSound;
    public AudioClip hurtSound;

    [Header("Coin Flip Sounds")]
    public AudioClip coinSpinSound;
    public AudioClip coinLandSound;

    [Header("Enemy Death Sounds")]
    public AudioClip sporelingDeathSound;
    public AudioClip batDeathSound;
    public AudioClip golemDeathSound;
    public AudioClip necromancerDeathSound;

    [Header("UI Sounds")]
    public AudioClip hoverSound;

    [Header("Game Ending Sounds")]
    public AudioClip victorySound;
    public AudioClip gameOverSound;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);

        if (sfxSource == null)
            sfxSource = GetComponent<AudioSource>();
    }

    public void PlaySound(AudioClip clip)
    {
        if (clip != null && sfxSource != null)
            sfxSource.PlayOneShot(clip);
    }

    public void PlayRock() => PlaySound(rockSound);
    public void PlayPaper() => PlaySound(paperSound);
    public void PlayScissors() => PlaySound(scissorsSound);
    public void PlayBlock() => PlaySound(blockSound);
    public void PlayCounter() => PlaySound(counterSound);
    public void PlayHurt() => PlaySound(hurtSound);

    public void PlayCoinSpin() => PlaySound(coinSpinSound);
    public void PlayCoinLand() => PlaySound(coinLandSound);

    public void PlayEnemyDeath(int encounter)
    {
        switch (encounter)
        {
            case 1: PlaySound(sporelingDeathSound); break;
            case 2: PlaySound(batDeathSound); break;
            case 3: PlaySound(golemDeathSound); break;
            case 4: PlaySound(necromancerDeathSound); break;
        }
    }

    public void PlayHover() => PlaySound(hoverSound);
    public void PlayVictory() => PlaySound(victorySound);
    public void PlayGameOver() => PlaySound(gameOverSound);
}
