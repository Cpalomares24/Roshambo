using UnityEngine;

public class UpgradeManager : MonoBehaviour
{
    [Header("Player")]
    public CombatStats player;

    public void UpgradeRock()
    {
        player.rockDamage += 2;

        Debug.Log("Rock upgraded! Damage: " + player.rockDamage);
    }

    public void UpgradeScissors()
    {
        player.scissorsDamage += 1;

        Debug.Log("Scissors upgraded! Damage: " + player.scissorsDamage);
    }

    public void UpgradeBleed()
    {
        player.scissorsBleed += 1;

        Debug.Log("Bleed upgraded! Damage: " + player.scissorsBleed);
    }

    public void UpgradePaper()
    {
        player.paperShield += 2;

        Debug.Log("Paper upgraded! Shield: " + player.paperShield);
    }


    [ContextMenu("Test Rock Upgrade")]
    public void TestRockUpgrade()
    {
        UpgradeRock();
    }

    [ContextMenu("Test Scissors Upgrade")]
    public void TestScissorsUpgrade()
    {
        UpgradeScissors();
    }

    [ContextMenu("Test Bleed Upgrade")]
    public void TestBleedUpgrade()
    {
        UpgradeBleed();
    }

    [ContextMenu("Test Paper Upgrade")]
    public void TestPaperUpgrade()
    {
        UpgradePaper();
    }


    [Header("Upgrade UI")]
    public GameObject upgradePanel;

    [Header("Combat Reference")]
    public CombatManager combatManager;
    public void ShowUpgrades()
    {
        upgradePanel.SetActive(true);

        combatManager.combatButtons.SetActive(false);
        combatManager.defenseButtons.SetActive(false);

        Debug.Log("Choose an upgrade!");
    }
    public void SelectRockUpgrade()
    {
        UpgradeRock();
        FinishUpgrade();
    }
    public void SelectScissorsUpgrade()
    {
        UpgradeScissors();
        FinishUpgrade();
    }
    public void SelectBleedUpgrade()
    {
        UpgradeBleed();
        FinishUpgrade();
    }
    public void SelectPaperUpgrade()
    {
        UpgradePaper();
        FinishUpgrade();
    }
    private void FinishUpgrade()
    {
        upgradePanel.SetActive(false);
        combatManager.BeginNextEncounter();
    }
}
