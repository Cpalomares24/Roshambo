
using UnityEngine;

public class CardInventory : MonoBehaviour
{
    [Header("Starting Cards")]
    public int rockCards = 5;
    public int paperCards = 5;
    public int scissorsCards = 5;


    public bool HasAttackCards()
    {
        return rockCards > 0 ||
           paperCards > 0 ||
           scissorsCards > 0;
    }
}
