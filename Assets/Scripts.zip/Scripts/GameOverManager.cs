
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameOverManager : MonoBehaviour
{
    [Header("Game Over Panels")]
    public GameObject victoryPanel;
    public GameObject defeatPanel;

    void Start()
    {
        victoryPanel.SetActive(false);
        defeatPanel.SetActive(false);
    }

    public void ShowVictory()
    {
        if (victoryPanel.activeSelf)
            return;

        victoryPanel.SetActive(true);

        // Play victory sound when the player wins.
        if (AudioManager.Instance != null)
            AudioManager.Instance.PlayVictory();
    }

    public void ShowDefeat()
    {
        if (defeatPanel.activeSelf)
            return;

        defeatPanel.SetActive(true);

        // Play defeat sound when the player loses.
        if (AudioManager.Instance != null)
            AudioManager.Instance.PlayGameOver();
    }

    public void RestartGame()
    {
        SceneManager.LoadScene(
            SceneManager.GetActiveScene().name
        );
    }

    public void ReturnToMainMenu()
    {
        SceneManager.LoadScene("MainMenu");
    }
}
