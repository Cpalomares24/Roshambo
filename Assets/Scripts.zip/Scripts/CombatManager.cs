
using UnityEngine;
using System.Collections;

public class CombatManager : MonoBehaviour
{
    [Header("Combat Participants")]
    public CombatStats player;
    public CombatStats enemy;

    [Header("Card Inventory")]
    public CardInventory playerCards;

    [Header("Upgrade System")]
    public UpgradeManager upgradeManager;

    [Header("Combat Systems")]
    public AttackSystem attackSystem;
    public EnemyAI enemyAI;

    [Header("Pre-Boss System")]
    public PreBossManager preBossManager;

    [Header("Turn Information")]
    public int turnNumber = 1;
    public bool playerAttacksFirst;

    [Header("Combat Phase")]
    public bool isAttackPhase = true;
    public bool isPlayerTurn = true;

    [Header("Turn Progress")]
    public bool playerHasAttacked = false;
    public bool enemyHasAttacked = false;

    [Header("Combat Buttons")]
    public GameObject combatButtons;
    public GameObject defenseButtons;

    [Header("Battle Animations")]
    public BattleAnimator battleAnimator;

    [Header("Encounter System")]
    public EncounterManager encounterManager;

    [Header("Battle Messages")]
    public BattleDisplay battleDisplay;

    [Header("Game Over System")]
    public GameOverManager gameOverManager;

    [Header("Coin Flip Animation")]
    public CoinFlipAnimator coinFlipAnimator;

    private bool actionInProgress = false;

    void Start()
    {
        encounterManager.StartEncounter();
        StartTurn();
    }

    public void FlipCoin()
    {
        playerAttacksFirst = Random.Range(0, 2) == 0;

        Debug.Log(
            playerAttacksFirst
                ? "Player attacks first!"
                : "Enemy attacks first!"
        );
    }

    public void StartTurn()
    {
        Debug.Log("Turn " + turnNumber + " started.");

        playerHasAttacked = false;
        enemyHasAttacked = false;

        FlipCoin();

        isPlayerTurn = playerAttacksFirst;
        isAttackPhase = playerAttacksFirst;

        // Wait for the coin animation before allowing card selection.
        StartCoroutine(ShowCoinFlipThenBeginTurn());
    }

    private IEnumerator ShowCoinFlipThenBeginTurn()
    {
        actionInProgress = true;
        HideCombatButtons();

        if (coinFlipAnimator != null)
        {
            yield return StartCoroutine(
                coinFlipAnimator.PlayCoinFlip(playerAttacksFirst)
            );
        }
        else
        {
            Debug.LogWarning("CoinFlipAnimator is not assigned on CombatManager.");
        }

        battleDisplay.ShowInstantMessage(
            playerAttacksFirst
                ? "Your turn! Choose an attack."
                : "Enemy attacks first! Choose your defense."
        );

        actionInProgress = false;
        UpdateCombatButtons();
    }

    public void FinishDefense()
    {
        enemyHasAttacked = true;

        if (CheckBattleOver())
            return;

        if (playerHasAttacked)
        {
            EndTurn();
        }
        else
        {
            isPlayerTurn = true;
            isAttackPhase = true;

            battleDisplay.ShowInstantMessage(
                "Choose your attack!"
            );

            UpdateCombatButtons();
        }
    }

    public void EndTurn()
    {
        if (CheckBattleOver())
            return;

        player.ProcessEndOfTurn();
        enemy.ProcessEndOfTurn();

        if (CheckBattleOver())
            return;

        Debug.Log("Turn " + turnNumber + " ended.");

        turnNumber++;
        StartTurn();
    }

    public bool CheckBattleOver()
    {
        if (player.IsDefeated())
        {
            Debug.Log("DEFEAT! Player defeated!");
            gameOverManager.ShowDefeat();

            combatButtons.SetActive(false);
            defenseButtons.SetActive(false);

            return true;
        }

        if (enemy.IsDefeated())
        {
            Debug.Log("Enemy defeated!");
            HandleEnemyDefeat();
            return true;
        }

        return false;
    }

    // --------------------------------
    // PLAYER ROCK ATTACK
    // --------------------------------

    public void PlayerRockAttack()
    {
        if (actionInProgress || battleDisplay.IsDialogueActive)
            return;

        if (playerCards.rockCards <= 0)
            return;

        // Play immediately when the card is selected.
        if (AudioManager.Instance != null)
            AudioManager.Instance.PlayRock();

        StartCoroutine(PlayerRockSequence());
    }

    private IEnumerator PlayerRockSequence()
    {
        actionInProgress = true;
        HideCombatButtons();

        playerCards.rockCards--;

        battleDisplay.ShowInstantMessage("You used Rock!");

        yield return StartCoroutine(
            battleAnimator.PlayAttackSymbol(true, 0)
        );

        yield return new WaitForSeconds(0.5f);

        int enemyDefense = enemyAI.ChooseDefense(0);

        yield return StartCoroutine(
            PlayEnemyDefense(enemyDefense)
        );

        if (enemyDefense == 2)
            enemy.AddShield(enemy.paperShield);

        bool blocked = enemyDefense == 0;

        int previousHealth = enemy.currentHealth;

        attackSystem.RockAttack(player, enemy, blocked);

        string resultMessage;

        if (blocked)
        {
            resultMessage = "Your Rock attack was blocked!";
        }
        else
        {
            int damageDealt =
                previousHealth - enemy.currentHealth;

            resultMessage = damageDealt > 0
                ? "Enemy took " + damageDealt + " damage!"
                : "Enemy's Shield absorbed the attack!";
        }

        yield return StartCoroutine(
            battleDisplay.ShowMessageAndWait(resultMessage)
        );

        actionInProgress = false;
        FinishAttack();
    }

    // --------------------------------
    // PLAYER SCISSORS ATTACK
    // --------------------------------

    public void PlayerScissorsAttack()
    {
        if (actionInProgress || battleDisplay.IsDialogueActive)
            return;

        if (playerCards.scissorsCards <= 0)
            return;

        // Play immediately when the card is selected.
        if (AudioManager.Instance != null)
            AudioManager.Instance.PlayScissors();

        StartCoroutine(PlayerScissorsSequence());
    }

    private IEnumerator PlayerScissorsSequence()
    {
        actionInProgress = true;
        HideCombatButtons();

        playerCards.scissorsCards--;

        battleDisplay.ShowInstantMessage("You used Scissors!");

        yield return StartCoroutine(
            battleAnimator.PlayAttackSymbol(true, 1)
        );

        yield return new WaitForSeconds(0.5f);

        int enemyDefense = enemyAI.ChooseDefense(1);

        yield return StartCoroutine(
            PlayEnemyDefense(enemyDefense)
        );

        if (enemyDefense == 2)
            enemy.AddShield(enemy.paperShield);

        bool countered = enemyDefense == 1;

        int previousEnemyHealth = enemy.currentHealth;
        int previousPlayerHealth = player.currentHealth;

        attackSystem.ScissorsAttack(player, enemy, countered);

        string resultMessage;

        if (countered)
        {
            int damageTaken =
                previousPlayerHealth - player.currentHealth;

            resultMessage = damageTaken > 0
                ? "Your Scissors was countered! You took " +
                  damageTaken + " damage!"
                : "Your Scissors was countered! Shield absorbed it!";
        }
        else
        {
            int damageDealt =
                previousEnemyHealth - enemy.currentHealth;

            resultMessage = damageDealt > 0
                ? "Enemy took " + damageDealt +
                  " damage and is bleeding!"
                : "Enemy's Shield absorbed your Scissors!";
        }

        yield return StartCoroutine(
            battleDisplay.ShowMessageAndWait(resultMessage)
        );

        actionInProgress = false;
        FinishAttack();
    }

    // --------------------------------
    // PLAYER PAPER ATTACK
    // --------------------------------

    public void PlayerPaperAttack()
    {
        if (actionInProgress || battleDisplay.IsDialogueActive)
            return;

        if (playerCards.paperCards <= 0)
            return;

        // Play immediately when the card is selected.
        if (AudioManager.Instance != null)
            AudioManager.Instance.PlayPaper();

        StartCoroutine(PlayerPaperSequence());
    }

    private IEnumerator PlayerPaperSequence()
    {
        actionInProgress = true;
        HideCombatButtons();

        playerCards.paperCards--;

        battleDisplay.ShowInstantMessage("You used Paper!");

        yield return StartCoroutine(
            battleAnimator.PlayPaperAnimation(true)
        );

        player.AddShield(player.paperShield);

        yield return new WaitForSeconds(0.5f);

        int enemyDefense = enemyAI.ChooseDefense(2);

        yield return StartCoroutine(
            PlayEnemyDefense(enemyDefense, true)
        );

        if (enemyDefense == 2)
            enemy.AddShield(enemy.paperShield);

        yield return StartCoroutine(
            battleDisplay.ShowMessageAndWait(
                "You gained " + player.paperShield + " Shield!"
            )
        );

        actionInProgress = false;
        FinishAttack();
    }

    // --------------------------------
    // ENEMY DEFENSE ANIMATION
    // --------------------------------

    private IEnumerator PlayEnemyDefense(int enemyDefense, bool paperAttack = false)
    {
        string defenseName = enemyDefense == 0
            ? "Block"
            : enemyDefense == 1
                ? "Counter"
                : "Paper";

        battleDisplay.ShowInstantMessage(
            "Enemy used " + defenseName + "!"
        );

        // Play the defense sound when the defense animation begins.
        // Rock/Scissors Block and Counter sounds are handled by AttackSystem,
        // so only play those here when Paper was the player's attack.
        if (AudioManager.Instance != null)
        {
            if (enemyDefense == 2)
                AudioManager.Instance.PlayPaper();
            else if (paperAttack && enemyDefense == 0)
                AudioManager.Instance.PlayBlock();
            else if (paperAttack && enemyDefense == 1)
                AudioManager.Instance.PlayCounter();
        }

        if (enemyDefense == 2)
        {
            yield return StartCoroutine(
                battleAnimator.PlayPaperAnimation(false)
            );
        }
        else
        {
            yield return StartCoroutine(
                battleAnimator.PlayDefenseStance(false, enemyDefense)
            );
        }

        yield return new WaitForSeconds(0.5f);
    }

    // --------------------------------
    // PLAYER BLOCK DEFENSE
    // --------------------------------

    public void PlayerBlock()
    {
        if (actionInProgress || battleDisplay.IsDialogueActive)
            return;

        StartCoroutine(PlayerBlockSequence());
    }

    private IEnumerator PlayerBlockSequence()
    {
        actionInProgress = true;
        HideCombatButtons();

        int attackChoice = enemyAI.ChooseAttack();

        // Enemy attack sound plays when its attack is revealed.
        if (AudioManager.Instance != null)
        {
            if (attackChoice == 0)
                AudioManager.Instance.PlayRock();
            else
                AudioManager.Instance.PlayScissors();
        }

        battleDisplay.ShowInstantMessage(
            attackChoice == 0
                ? "Enemy used Rock!"
                : "Enemy used Scissors!"
        );

        yield return StartCoroutine(
            battleAnimator.PlayAttackSymbol(false, attackChoice)
        );

        yield return new WaitForSeconds(0.5f);

        battleDisplay.ShowInstantMessage("You used Block!");

        yield return StartCoroutine(
            battleAnimator.PlayDefenseStance(true, 0)
        );

        yield return new WaitForSeconds(0.5f);

        int previousHealth = player.currentHealth;

        if (attackChoice == 0)
            attackSystem.RockAttack(enemy, player, true);
        else
            attackSystem.ScissorsAttack(enemy, player, false);

        string resultMessage;

        if (attackChoice == 0)
        {
            resultMessage = "You blocked the enemy's Rock!";
        }
        else
        {
            int damageTaken =
                previousHealth - player.currentHealth;

            resultMessage = damageTaken > 0
                ? "Block failed! You took " +
                  damageTaken + " damage!"
                : "Block failed, but Shield absorbed the attack!";
        }

        yield return StartCoroutine(
            battleDisplay.ShowMessageAndWait(resultMessage)
        );

        actionInProgress = false;
        FinishDefense();
    }

    // --------------------------------
    // PLAYER COUNTER DEFENSE
    // --------------------------------

    public void PlayerCounter()
    {
        if (actionInProgress || battleDisplay.IsDialogueActive)
            return;

        StartCoroutine(PlayerCounterSequence());
    }

    private IEnumerator PlayerCounterSequence()
    {
        actionInProgress = true;
        HideCombatButtons();

        int attackChoice = enemyAI.ChooseAttack();

        // Enemy attack sound plays when its attack is revealed.
        if (AudioManager.Instance != null)
        {
            if (attackChoice == 0)
                AudioManager.Instance.PlayRock();
            else
                AudioManager.Instance.PlayScissors();
        }

        battleDisplay.ShowInstantMessage(
            attackChoice == 0
                ? "Enemy used Rock!"
                : "Enemy used Scissors!"
        );

        yield return StartCoroutine(
            battleAnimator.PlayAttackSymbol(false, attackChoice)
        );

        yield return new WaitForSeconds(0.5f);

        battleDisplay.ShowInstantMessage("You used Counter!");

        yield return StartCoroutine(
            battleAnimator.PlayDefenseStance(true, 1)
        );

        yield return new WaitForSeconds(0.5f);

        int previousPlayerHealth = player.currentHealth;
        int previousEnemyHealth = enemy.currentHealth;

        if (attackChoice == 0)
            attackSystem.RockAttack(enemy, player, false);
        else
            attackSystem.ScissorsAttack(enemy, player, true);

        string resultMessage;

        if (attackChoice == 0)
        {
            int damageTaken =
                previousPlayerHealth - player.currentHealth;

            resultMessage =
                "Counter failed against Rock! You took " +
                damageTaken + " damage!";
        }
        else
        {
            int damageDealt =
                previousEnemyHealth - enemy.currentHealth;

            resultMessage =
                "Counter succeeded! Enemy took " +
                damageDealt + " damage!";
        }

        yield return StartCoroutine(
            battleDisplay.ShowMessageAndWait(resultMessage)
        );

        actionInProgress = false;
        FinishDefense();
    }

    // --------------------------------
    // PLAYER PAPER DEFENSE
    // --------------------------------

    public void PlayerDefensePaper()
    {
        if (actionInProgress || battleDisplay.IsDialogueActive)
            return;

        if (playerCards.paperCards <= 0)
            return;

        StartCoroutine(PlayerDefensePaperSequence());
    }

    private IEnumerator PlayerDefensePaperSequence()
    {
        actionInProgress = true;
        HideCombatButtons();

        playerCards.paperCards--;

        int attackChoice = enemyAI.ChooseAttack();

        // Enemy attack sound plays when its attack is revealed.
        if (AudioManager.Instance != null)
        {
            if (attackChoice == 0)
                AudioManager.Instance.PlayRock();
            else
                AudioManager.Instance.PlayScissors();
        }

        battleDisplay.ShowInstantMessage(
            attackChoice == 0
                ? "Enemy used Rock!"
                : "Enemy used Scissors!"
        );

        yield return StartCoroutine(
            battleAnimator.PlayAttackSymbol(false, attackChoice)
        );

        yield return new WaitForSeconds(0.5f);

        battleDisplay.ShowInstantMessage("You used Paper!");

        // Play Paper when its defense animation starts, not at button click.
        if (AudioManager.Instance != null)
            AudioManager.Instance.PlayPaper();

        yield return StartCoroutine(
            battleAnimator.PlayPaperAnimation(true)
        );

        player.AddShield(player.paperShield);

        yield return new WaitForSeconds(0.5f);

        int previousHealth = player.currentHealth;

        if (attackChoice == 0)
            attackSystem.RockAttack(enemy, player, false);
        else
            attackSystem.ScissorsAttack(enemy, player, false);

        int damageTaken =
            previousHealth - player.currentHealth;

        string resultMessage = damageTaken > 0
            ? "You gained Shield, but took " +
              damageTaken + " damage!"
            : "Your Shield protected you!";

        yield return StartCoroutine(
            battleDisplay.ShowMessageAndWait(resultMessage)
        );

        actionInProgress = false;
        FinishDefense();
    }

    // --------------------------------
    // COMBAT BUTTONS
    // --------------------------------

    private void HideCombatButtons()
    {
        combatButtons.SetActive(false);
        defenseButtons.SetActive(false);
    }

    public void UpdateCombatButtons()
    {
        if (actionInProgress || battleDisplay.IsDialogueActive)
        {
            HideCombatButtons();
            return;
        }

        bool showAttack = isAttackPhase && isPlayerTurn;

        if (player.IsDefeated() || enemy.IsDefeated())
        {
            HideCombatButtons();
            return;
        }

        if (showAttack && CheckOutOfCards())
            return;

        combatButtons.SetActive(showAttack);
        defenseButtons.SetActive(!showAttack);
    }

    public void SwitchToDefense()
    {
        isAttackPhase = false;
        isPlayerTurn = false;

        battleDisplay.ShowInstantMessage(
            "Choose your defense!"
        );

        UpdateCombatButtons();

        Debug.Log("Player is now defending!");
    }

    public void FinishAttack()
    {
        if (CheckBattleOver())
            return;

        playerHasAttacked = true;

        if (enemyHasAttacked)
            EndTurn();
        else
            SwitchToDefense();
    }

    // Retained for compatibility with existing scripts.
    public void EnemyAttack(bool playerBlocked)
    {
        int attackChoice = Random.Range(0, 2);

        if (attackChoice == 0)
            attackSystem.RockAttack(enemy, player, playerBlocked);
        else
            attackSystem.ScissorsAttack(enemy, player, false);
    }

    // --------------------------------
    // CARD INVENTORY
    // --------------------------------

    public bool CheckOutOfCards()
    {
        if (!playerCards.HasAttackCards())
        {
            Debug.Log("DEFEAT! You ran out of cards!");
            gameOverManager.ShowDefeat();
            HideCombatButtons();
            return true;
        }

        return false;
    }

    // --------------------------------
    // ENCOUNTER SYSTEM
    // --------------------------------

    public void BeginNextEncounter()
    {
        if (encounterManager.AdvanceEncounter())
        {
            if (encounterManager.currentEncounter < 4)
            {
                playerCards.rockCards += 1;
                playerCards.scissorsCards += 1;

                Debug.Log(
                    "Reward: +1 Rock and +1 Scissors!"
                );
            }

            turnNumber = 1;
            StartTurn();

            Debug.Log("Next encounter ready!");
        }
    }

    public void HandleEnemyDefeat()
    {
        if (!encounterManager.HasMoreEncounters())
        {
            Debug.Log("GAME COMPLETE! Boss defeated!");
            gameOverManager.ShowVictory();
            HideCombatButtons();
            return;
        }

        if (encounterManager.currentEncounter == 3)
            preBossManager.ShowPreBossChoice();
        else
            upgradeManager.ShowUpgrades();
    }
}
