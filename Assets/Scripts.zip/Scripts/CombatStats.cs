

using UnityEngine;

public class CombatStats : MonoBehaviour
{
    [Header("Health")]
    public int maxHealth = 20;
    public int currentHealth = 20;

    [Header("Shield")]
    public int shield = 0;

    [Header("Bleed")]
    public int bleedDamage = 0;
    public int bleedTurnsRemaining = 0;

    [Header("Card Strength")]
    public int rockDamage = 5;
    public int scissorsDamage = 3;
    public int scissorsBleed = 1;
    public int paperShield = 3;

    // Resets health and status effects for a new battle.
    public void Initialize()
    {
        currentHealth = maxHealth;
        shield = 0;
        bleedDamage = 0;
        bleedTurnsRemaining = 0;
    }

    // Shield absorbs damage before health is reduced.
    public int TakeDamage(int damage)
    {
        int absorbed = Mathf.Min(shield, damage);
        shield -= absorbed;

        int remainingDamage = damage - absorbed;
        currentHealth = Mathf.Max(0, currentHealth - remainingDamage);

        return remainingDamage;
    }

    // Adds shield when Paper is played.
    public void AddShield(int amount)
    {
        shield += amount;
    }

    // Applies bleed after Scissors penetrates the shield.
    public void ApplyBleed(int amount, int duration)
    {
        bleedDamage = amount;
        bleedTurnsRemaining = duration;
    }

    // Called after both characters finish their attack and defense.
    public void ProcessEndOfTurn()
    {
        if (bleedTurnsRemaining > 0)
        {
            currentHealth = Mathf.Max(0, currentHealth - bleedDamage);
            bleedTurnsRemaining--;
            
            if (bleedTurnsRemaining == 0)
            {
                bleedDamage = 0;
            }
        }
    }

    public bool IsDefeated()
    {
        return currentHealth <= 0;
    }
}

